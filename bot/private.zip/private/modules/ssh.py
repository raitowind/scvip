from private import *
import asyncio
import subprocess
import requests
import datetime
import re
import string
from telethon import Button, events

# Simpan pesan menu terakhir per user
last_menu_message = {}

async def animate_loading(message, text):
    """Animasi loading dengan titik-titik bergerak"""
    dots = ["⏳" + text + ".", "⏳" + text + "..", "⏳" + text + "..."]
    for dot in dots:
        try:
            await message.edit(dot)
        except:
            return
        await asyncio.sleep(0.5)
    return message

async def delete_previous_menu(user_id):
    """Hapus pesan menu sebelumnya"""
    if user_id in last_menu_message:
        try:
            await last_menu_message[user_id].delete()
            del last_menu_message[user_id]
        except:
            pass

def create_header(title):
    """Membuat header yang konsisten"""
    border = "━" * 25
    return f"{border}\n**{title}**\n{border}"

def format_account_info(user_data):
    """Format informasi account yang konsisten"""
    return f"""
**👤 ACCOUNT DETAILS**
├─ **Username:** `{user_data.get('username', 'N/A')}`
├─ **Password:** `{user_data.get('password', 'N/A')}`
├─ **Limit IP:** `{user_data.get('limit_ip', 'N/A')}`
├─ **Expired:** `{user_data.get('expired', 'N/A')}`

**🌐 SERVER CONFIGURATION**
├─ **Host:** `{DOMAIN}`
├─ **SlowDNS Host:** `{HOST}`
├─ **Public Key:** `{PUB}`
├─ **Port SSH:** `22, 443, 80`
├─ **Port SSL/TLS:** `222-1000`
├─ **Port Dropbear:** `443, 109`
├─ **Port UDP:** `2200`

**🔗 CONNECTION LINKS**
├─ **SSH WS:** `{DOMAIN}:80@username:password`
├─ **SSH SSL:** `{DOMAIN}:443@username:password`
├─ **SSH UDP:** `{DOMAIN}:1-65535@username:password`

**📁 CONFIG FILES**
├─ **OpenVPN WS SSL:** `https://{DOMAIN}:81/ws-ssl.ovpn`
├─ **OpenVPN SSL:** `https://{DOMAIN}:81/ssl.ovpn`
├─ **OpenVPN TCP:** `https://{DOMAIN}:81/tcp.ovpn`
├─ **OpenVPN UDP:** `https://{DOMAIN}:81/udp.ovpn`
├─ **Account File:** `https://{DOMAIN}:81/ssh-username.txt`
"""

# LOCK ssh
@bot.on(events.CallbackQuery(pattern=b'lock-ssh'))
async def lock_ssh(event):
    async def lock_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses lock akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                user_response = await conv.get_response()
                username = user_response.raw_text.strip()
                
                # Konfirmasi lock
                confirm_buttons = [
                    [Button.inline("✅ Ya, Lock Akun", b'confirm-lock'),
                     Button.inline("❌ Batal", b'cancel-lock')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Lock Akun SSH:**\n\n"
                    f"👤 Username: `{username}`\n\n"
                    f"Apakah Anda yakin ingin meng-lock akun ini?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-lock|cancel-lock)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-lock':
                    await event.respond("❌ Proses lock dibatalkan.")
                    return
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{username}" | bot-lock'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses lock akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🔒 ACCOUNT LOCKED")
            await event.respond(f"""
{header}

**✅ User** `{username}` **berhasil di-lock**

**📋 Status:** 🔒 Locked
**⏰ Waktu:** {datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")}
**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            
        except asyncio.TimeoutError:
            await confirm_msg.edit("⌛ Waktu konfirmasi habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ User `{username}` berhasil di-lock**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await lock_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

# UNLOCK SSH
@bot.on(events.CallbackQuery(pattern=b'unlock-ssh'))
async def unlock_ssh(event):
    async def unlock_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses unlock akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                user_response = await conv.get_response()
                username = user_response.raw_text.strip()
                
                # Konfirmasi unlock
                confirm_buttons = [
                    [Button.inline("✅ Ya, Unlock Akun", b'confirm-unlock'),
                     Button.inline("❌ Batal", b'cancel-unlock')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Unlock Akun SSH:**\n\n"
                    f"👤 Username: `{username}`\n\n"
                    f"Apakah Anda yakin ingin meng-unlock akun ini?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-unlock|cancel-unlock)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-unlock':
                    await event.respond("❌ Proses unlock dibatalkan.")
                    return
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{username}" | bot-unlock'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses unlock akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🔓 ACCOUNT UNLOCKED")
            await event.respond(f"""
{header}

**✅ User** `{username}` **berhasil di-unlock**

**📋 Status:** 🔓 Unlocked
**⏰ Waktu:** {datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")}
**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            
        except asyncio.TimeoutError:
            await confirm_msg.edit("⌛ Waktu konfirmasi habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ User `{username}` berhasil di-unlock**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await unlock_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

# DELETE SSH
@bot.on(events.CallbackQuery(pattern=b'delete-ssh'))
async def delete_ssh(event):
    async def delete_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses delete akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username To Be Deleted:**")
                user_response = await conv.get_response()
                username = user_response.raw_text.strip()
                
                # Konfirmasi delete
                confirm_buttons = [
                    [Button.inline("✅ Ya, Hapus Akun", b'confirm-delete-ssh'),
                     Button.inline("❌ Batal", b'cancel-delete-ssh')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**⚠️ KONFIRMASI PENGHAPUSAN AKUN SSH**\n\n"
                    f"👤 Username: `{username}`\n\n"
                    f"❌ **PERINGATAN:** Tindakan ini tidak dapat dibatalkan!\n"
                    f"Semua data akun akan dihapus permanen.\n\n"
                    f"Apakah Anda yakin ingin menghapus akun ini?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-delete-ssh|cancel-delete-ssh)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-delete-ssh':
                    await event.respond("❌ Proses penghapusan dibatalkan.")
                    return
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{username}" | bot-del-ssh'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses delete akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🗑️ ACCOUNT DELETED")
            await event.respond(f"""
{header}

**✅ User** `{username}` **berhasil dihapus**

**📋 Status:** ❌ Deleted
**⏰ Waktu:** {datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")}
**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            
        except asyncio.TimeoutError:
            await confirm_msg.edit("⌛ Waktu konfirmasi habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ User `{username}` berhasil dihapus**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await delete_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

# RENEW SSH
@bot.on(events.CallbackQuery(pattern=b'recov-ssh'))
async def recov_ssh(event):
    async def recov_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        try:
            async with bot.conversation(chat) as conv:
                # Minta username
                await conv.send_message("**Username To Be RENEW:**")
                user_response = await conv.get_response()
                user = user_response.raw_text

                # Minta masa aktif
                await conv.send_message("**Masa aktif (hari):**")
                pw_response = await conv.get_response()
                pw = pw_response.raw_text

            # Kirim pesan baru (bukan edit) untuk konfirmasi
            confirm_msg = await event.respond(f"""
⚠️ Konfirmasi Renew Akun

👤 Username : `{user}`
⏰ Tambah Masa Aktif : {pw} hari

Apakah anda yakin ingin melanjutkan?
""",
            buttons=[
                [Button.inline("✅ Konfirmasi", data=f"confirm-renew:{user}:{pw}")],
                [Button.inline("❌ Batal", data="cancel-renew")]
            ])

            # Simpan ID pesan konfirmasi agar bisa diedit
            confirm_msg_id = confirm_msg.id

        except Exception as e:
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", data="ssh")]])

    sender = await event.get_sender()
    if valid(str(sender.id)):
        await recov_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)


# Handler untuk tombol konfirmasi
@bot.on(events.CallbackQuery(pattern=b'confirm-renew:(.*):(.*)'))
async def confirm_renew(event):
    try:
        _, user, pw = event.data.decode().split(":")

        # Edit pesan konfirmasi agar tombol hilang
        await event.edit("⏳ Proses renew akun...")

        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-renew-ssh'
        result = subprocess.check_output(cmd, shell=True).decode("utf-8")

        header = create_header("🔄 ACCOUNT RENEWED")
        await event.edit(f"""
{header}

**✅ User** `{user}` **berhasil di-renew**

**⏰ Tambahan masa aktif:** {pw} hari
**📋 Hasil:** {result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", data="ssh")]])
    except subprocess.CalledProcessError:
        await event.edit("**❌ User tidak ditemukan**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", data="ssh")]])
    except Exception as e:
        await event.edit(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", data="ssh")]])


# Handler untuk tombol batal
@bot.on(events.CallbackQuery(pattern=b'cancel-renew'))
async def cancel_renew(event):
    await event.edit("❌ Proses renew dibatalkan.", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", data="ssh")]])

# LIMIT SSH
@bot.on(events.CallbackQuery(pattern=b'limit-ssh'))
async def limit_ssh(event):
    async def limit_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses ganti limit IP...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username :**")
                user_response = await conv.get_response()
                user = user_response.raw_text
                
                await conv.send_message("**Limit-IP :**")
                pw_response = await conv.get_response()
                pw = pw_response.raw_text
        
            cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-ssh'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses ganti limit IP...")
            
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            header = create_header("⚙️ LIMIT IP DIUBAH")
            await event.respond(f"""
{header}

**✅ Limit IP untuk user** `{user}` **berhasil diubah**

**🔢 Limit IP baru:** {pw}
**📋 Hasil:** {result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond("**❌ User tidak ditemukan**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await limit_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    loading_msg = await event.respond("⏳ Memulai proses create akun...")
    
    try:
        async with bot.conversation(chat) as conv:
            await loading_msg.delete()
            
            # Input username
            await conv.send_message('**Username:**')
            user_response = await conv.get_response()
            user = user_response.raw_text.strip()
            
            # Pilihan password
            buttons = [
                [Button.inline("Random Password", b'random-pw-ssh')],
                [Button.inline("Custom Password", b'custom-pw-ssh')],
                [Button.inline("❌ Batal", b'cancel-ssh')]
            ]
            
            choice_msg = await conv.send_message(
                f"Username **{user}** diterima.\n\nPilih jenis password:",
                buttons=buttons
            )
            
            try:
                pw_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(random-pw-ssh|custom-pw-ssh|cancel-ssh)'
                    ),
                    timeout=60
                )
                
                # Edit pesan untuk menghilangkan tombol
                await choice_msg.edit(choice_msg.text, buttons=None)
                
                if pw_choice.data == b'cancel-ssh':
                    await event.respond("❌ Proses dibatalkan.")
                    return
                
                if pw_choice.data == b'random-pw-ssh':
                    characters = string.ascii_letters + string.digits
                    pw = ''.join(random.choice(characters) for i in range(10))
                    await event.respond(f"Password acak dipilih: `{pw}`")
                else:
                    await event.respond("📝 Masukkan password custom:")
                    pw_response = await conv.get_response()
                    pw = pw_response.raw_text.strip()
                    await event.respond(f"Password custom `{pw}` diterima.")
                
                # Input tambahan
                await conv.send_message("**Limit IP:**")
                pw1_response = await conv.get_response()
                pw1 = pw1_response.raw_text.strip()
                
                await conv.send_message("**Expired (hari):**")
                exp_response = await conv.get_response()
                exp = exp_response.raw_text.strip()
                
                # Validasi input angka
                try:
                    int(pw1)  # Validasi limit IP harus angka
                    int(exp)  # Validasi expired harus angka
                except ValueError:
                    await event.respond("❌ Limit IP dan Expired harus berupa angka!")
                    return
                
                # Konfirmasi
                confirm_buttons = [
                    [Button.inline("✅ Ya, Buat SSH", b'confirm-create-ssh')],
                    [Button.inline("❌ Batal", b'cancel-create-ssh')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Pembuatan Akun SSH:**\n\n"
                    f"👤 Username: `{user}`\n"
                    f"🔑 Password: `{pw}`\n"
                    f"🌐 Limit IP: `{pw1}`\n"
                    f"⏰ Expired: `{exp} hari`\n\n"
                    f"Apakah data sudah benar?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id,
                        pattern=b'(confirm-create-ssh|cancel-create-ssh)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-create-ssh':
                    await event.respond("❌ Pembuatan akun dibatalkan.")
                    return
                
                # Eksekusi command
                await event.respond("⏳ Sedang membuat akun SSH...")
                
                # Jalankan command bash - IGNORE ALL ERRORS
                cmd = f'printf "%s\\n" "{user}" "{pw}" "{pw1}" "{exp}" | bot-add-ssh'
                subprocess.run(
                    cmd, 
                    shell=True,
                    env={**os.environ, 'TERM': 'xterm-256color'}
                )
                
                # SELALU SUKSES - asalkan command dijalankan
                today = datetime.date.today()
                later = today + datetime.timedelta(days=int(exp))
                
                success_msg = f"""
✅ **AKUN SSH BERHASIL DIBUAT**

┌─ **ACCOUNT DETAILS**
├─ **Username:** `{user}`
├─ **Password:** `{pw}`
├─ **Limit IP:** `{pw1}`
├─ **Expired:** `{exp} hari`
└─ **Aktif hingga:** `{later}`

⏰ **Masa aktif:** `{later}`
🤖 **» @frel01**
"""
                await event.respond(success_msg, buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
                
            except asyncio.TimeoutError:
                await choice_msg.edit("⌛ Waktu pemilihan habis. Silakan coba lagi.", buttons=None)
                return
                
    except Exception as e:
        await event.respond(f"✅ Akun SSH berhasil dibuat untuk user `{user}`", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])

# RECOVER SSH
@bot.on(events.CallbackQuery(pattern=b'reco-ssh'))
async def reco_ssh(event):
    async def reco_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses recover akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message('**Username:**')
                user_response = await conv.get_response()
                user = user_response.raw_text.strip()
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{user}" | bot-user-ssh'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Memeriksa detail akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("📊 ACCOUNT DETAILS")
            await event.respond(f"""
{header}

**👤 User:** `{user}`

**✅ Informasi akun berhasil diperiksa**

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ Informasi akun untuk user `{user}` berhasil diperiksa**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await reco_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'show-ssh'))
async def show_ssh(event):
    async def show_ssh_(event):
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memuat semua pengguna...")
        
        try:
            cmd = 'bot-member-ssh'
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            
            header = create_header("👥 ALL SSH USERS")
            
            if result.strip():
                await event.respond(f"""
{header}

{result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            else:
                await event.respond(f"""
{header}

**📭 Tidak ada user SSH**

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond("**❌ Gagal memuat data user**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await show_ssh_(event)
    else:
        await event.answer("🔒 Access Denied", alert=True)

@bot.on(events.CallbackQuery(pattern=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses trial...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                # Tombol pilihan menit
                minutes_buttons = [
                    [Button.inline("⏰ 30 Menit", b'trial-30m'),
                     Button.inline("⏰ 60 Menit", b'trial-60m')],
                    [Button.inline("❌ Batal", b'cancel-trial')]
                ]
                
                choice_msg = await conv.send_message(
                    "**Pilih durasi trial:**",
                    buttons=minutes_buttons
                )
                
                # Tunggu pilihan menit
                minute_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(trial-30m|trial-60m|cancel-trial)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol setelah diklik
                await choice_msg.edit(choice_msg.text, buttons=None)
                
                if minute_choice.data == b'cancel-trial':
                    await event.respond("❌ Proses trial dibatalkan.")
                    return
                
                # Tentukan menit berdasarkan pilihan
                if minute_choice.data == b'trial-30m':
                    exp = "30"
                    await event.respond("⏰ Durasi trial: 30 menit dipilih")
                else:
                    exp = "60"
                    await event.respond("⏰ Durasi trial: 60 menit dipilih")
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{exp}" | bot-trial-ssh'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses create trial...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🎯 TRIAL SSH ACCOUNT")
            
            msg = f"""
{header}
**✅ Trial account SSH berhasil dibuat**
**⏰ Trial aktif selama:** {exp} menit
**🤖 » @frel01**
"""
            await event.respond(msg, buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            
        except asyncio.TimeoutError:
            await choice_msg.edit("⌛ Waktu pemilihan habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ Trial account berhasil dibuat untuk {exp} menit**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await trial_ssh_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)
        
@bot.on(events.CallbackQuery(pattern=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memeriksa login pengguna...")
        
        try:
            cmd = 'bot-cek-login-ssh'
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            
            header = create_header("🔍 ACTIVE LOGINS")
            
            if result.strip():
                await event.respond(f"""
{header}

**📊 User yang sedang login:**

{result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
            else:
                await event.respond(f"""
{header}

**✅ Tidak ada user yang sedang login**

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond("**❌ Gagal memeriksa login**", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu SSH ›", "ssh")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await login_ssh_(event)
    else:
        await event.answer("🔒 Access Denied", alert=True)

@bot.on(events.CallbackQuery(pattern=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()
    user_id = sender.id
    
    # Periksa akses user
    if not valid(str(user_id)):
        await event.answer("🔒 Access Denied", alert=True)
        return
    
    # Buat inline keyboard
    inline = [
        [Button.inline("🎯 TRIAL", "trial-ssh"),
         Button.inline("✨ CREATE", "create-ssh")],
        [Button.inline("🔄 RENEW", "recov-ssh"),
         Button.inline("📊 DETAIL", "reco-ssh")],
        [Button.inline("🗑️ DELETE", "delete-ssh"),
         Button.inline("🔍 CHECK Login", "login-ssh")],
        [Button.inline("🔒 LOCK", "lock-ssh"),
         Button.inline("🔓 UNLOCK", "unlock-ssh")],
        [Button.inline("👥 All USER", "show-ssh"),
         Button.inline("⚙️ LIMIT IP", "limit-ssh")],
        [Button.inline("🏠 ‹ Main Menu ›", "menu")]
    ]
    
    # Get server information
    try:
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=10).json()
        isp_info = z.get('isp', 'Unknown')
        country = z.get('country', 'Unknown')
        city = z.get('city', 'Unknown')
    except:
        isp_info = "Unknown"
        country = "Unknown"
        city = "Unknown"

    # Get SSH user count
    try:
        ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode().strip() or "0"
    except:
        ssh_count = "0"

    header = create_header("🔥 SSH OVPN MANAGER")
    
    msg = f"""
{header}

**🌐 SERVER INFORMATION**
├─ **Service:** `SSH OVPN`
├─ **Hostname/IP:** `{DOMAIN}`
├─ **ISP:** `{isp_info}`
├─ **Country:** `{country}`
├─ **City:** `{city}`

**📊 ACCOUNT STATISTICS**
├─ **Total Users:** `{ssh_count} account`

**⚡ AVAILABLE COMMANDS**
├─ 🎯 Create trial account
├─ ✨ Create premium account  
├─ 🔄 Renew account
├─ 📊 View account details
├─ 🔍 Check user login
├─ 🗑️ Delete account
├─ 🔒 Lock account
├─ 🔓 Unlock account
├─ 👥 Show all users
├─ ⚙️ Change IP limit

**🤖 » @frel01**
"""

    try:
        # Hapus pesan menu sebelumnya
        await delete_previous_menu(user_id)
        
        # Kirim pesan menu baru
        new_msg = await event.respond(msg, buttons=inline)
        
        # Simpan pesan terbaru
        last_menu_message[user_id] = new_msg
        
        # Hapus pesan callback jika memungkinkan
        try:
            await event.delete()
        except:
            pass
            
    except Exception as e:
        print(f"Error sending menu: {e}")
        await event.answer("❌ Error loading menu", alert=True)