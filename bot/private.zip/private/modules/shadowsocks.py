from private import *
import asyncio
import subprocess
import requests
import datetime
import re
from telethon import Button, events

# Simpan pesan menu terakhir per user
last_menu_message = {}

async def animate_loading(message, text):
    """Animasi loading dengan titik-titik bergerak"""
    dots = ["⏳" + text + ".", "⏳" + text + "..", "⏳" + text + "..."]
    for dot in dots:
        try:
            await message.edit(dot)
        except:
            return
        await asyncio.sleep(0.5)
    return message

async def delete_previous_menu(user_id):
    """Hapus pesan menu sebelumnya"""
    if user_id in last_menu_message:
        try:
            await last_menu_message[user_id].delete()
            del last_menu_message[user_id]
        except:
            pass

@bot.on(events.CallbackQuery(pattern=b'create-shadowsocks'))
async def create_shadowsocks(event):
    async def create_shadowsocks_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses create akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message('**Username:**')
                user_response = await conv.get_response()
                user = user_response.raw_text
                
                await conv.send_message("**Quota (GB):**")
                pw_response = await conv.get_response()
                pw = pw_response.raw_text
                
                await conv.send_message("**Limit IP:**")
                pw1_response = await conv.get_response()
                pw1 = pw1_response.raw_text
                
                await conv.send_message("**Expired (Days):**")
                exp_response = await conv.get_response()
                exp = exp_response.raw_text
            
            cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{pw1}" | addss'

            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses create akun...")

            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            today = datetime.date.today()
            later = today + datetime.timedelta(days=int(exp))
            x = [x.group() for x in re.finditer("ss://(.*)", a)]
            
            if x:
                uuid_match = re.search("ss://(.*?)@", x[0])
                uuid = uuid_match.group(1) if uuid_match else "N/A"
                
                msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SHADOWSOCKS ACCOUNT 🕊️🐾**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `{pw} GB`
**» Limit IP    :** `{pw1}`
**» Pub Key     :** `{PUB}`
**» Port TLS    :** `222-1000`
**» Port GRPC   :** `443`
**» Port DNS    :** `443, 53`
**» Password    :** `{uuid}`
**» Ciphers     :** `aes-128-gcm`
**» Network     :** `(WS) or (gRPC)`
**» Path        :** `(/multi path)/ss-ws`
**» ServiceName :** `ss-grpc`
**━━━━━━━━━━━━━━━━**
**» Link TLS    :**
`{x[0]}`
**━━━━━━━━━━━━━━━━**
**» Link gRPC   :** 
`{x[1].replace(" ", "") if len(x) > 1 else x[0].replace(" ", "")}`
**━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/ss-{user}.txt
**━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@frel01**
"""
                await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            else:
                await event.respond(f"**Klik Link di atas untuk membuka Detail Account** `{user}` **Successfully Created**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
                
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**User** `{user}` **Successfully Created**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await create_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# LOCK shadowsocks
@bot.on(events.CallbackQuery(pattern=b'lock-shadowsocks'))
async def lock_shadowsocks(event):
    async def lock_shadowsocks_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses lock akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                exp_response = await conv.get_response()
                exp = exp_response.raw_text
        
            cmd = f'printf "%s\n" "{exp}" | bot-lock-ss'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses lock akun...")
            
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**User** `{exp}` **Successfully Locked**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            msg = f"""**Successfully Locked**"""
            await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await lock_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# UNLOCK shadowsocks
@bot.on(events.CallbackQuery(pattern=b'unlock-shadowsocks'))
async def unlock_shadowsocks(event):
    async def unlock_shadowsocks_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses unlock akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                exp_response = await conv.get_response()
                exp = exp_response.raw_text
        
            cmd = f'printf "%s\n" "{exp}" | bot-unlock-ss'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses unlock akun...")
            
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**User** `{exp}` **Successfully Unlock**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            msg = f"""**Successfully Unlocked**"""
            await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await unlock_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# GANTI LIMIT IP
@bot.on(events.CallbackQuery(pattern=b'limit-ss'))
async def limit_ss(event):
    async def limit_ss_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses ganti limit IP...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username :**")
                user_response = await conv.get_response()
                user = user_response.raw_text
                
                await conv.send_message("**Limit-IP :**")
                pw_response = await conv.get_response()
                pw = pw_response.raw_text
        
            cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-ss'

            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses ganti limit IP...")
            
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"""
{a}
 
**GANTI IP SHADOWSOCKS**
**» 🤖@frel01**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"`{user}` ** TIDAK DITEMUKAN! **", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await limit_ss_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
    async def cek_shadowsocks_(event):
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memeriksa pengguna...")
        
        try:
            cmd = 'bot-cek-ss'
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            
            await event.respond(f"""

{z}

**Shows Logged In Users Shadowsocks**
**» 🤖@frel01**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond("**Tidak ada user yang login atau terjadi error**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await cek_shadowsocks_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(pattern=b'show-ss'))
async def show_ss(event):
    async def show_ss_(event):
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memuat semua pengguna...")
        
        try:
            cmd = 'bot-member-ss'
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            
            await event.respond(f"""
{z}

**Show All SHADOWSOCKS User**
**» 🤖@frel01**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond("**Tidak ada user SHADOWSOCKS atau terjadi error**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await show_ss_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(pattern=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
    async def trial_shadowsocks_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses create trial...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Minutes:**")
                exp_response = await conv.get_response()
                exp = exp_response.raw_text
        
            cmd = f'printf "%s\n" "{exp}" | trialss'

            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses create trial...")
            
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            x = [x.group() for x in re.finditer("ss://(.*)", a)]
            
            if x:
                remarks_match = re.search("#(.*)", x[0])
                remarks = remarks_match.group(1) if remarks_match else "Trial User"
                
                uuid_match = re.search("ss://(.*?)@", x[0])
                uuid = uuid_match.group(1) if uuid_match else "N/A"
                
                msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SHADOWSOCKS ACCOUNT 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `Unlimited`
**» Pub Key     :** `{PUB}`
**» Port TLS    :** `222-1000`
**» Port GRPC   :** `443`
**» Port DNS    :** `443, 53`
**» Password    :** `{uuid}`
**» Ciphers     :** `aes-128-gcm`
**» Network     :** `(WS) or (gRPC)`
**» Path        :** `(/multi path)/ss-ws`
**» ServiceName :** `ss-grpc`
**━━━━━━━━━━━━━━━━**
**» Link TLS    :**
`{x[0]}`
**━━━━━━━━━━━━━━━━**
**» Link gRPC   :** 
`{x[1].replace(" ", "") if len(x) > 1 else x[0].replace(" ", "")}`
**━━━━━━━━━━━━━━━━**
**» Expired Until:** `{exp} Minutes`
**» 🤖@frel01**
"""
                await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            else:
                await event.respond("**Klik Link di atas untuk membuka Detail Account Trial**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
                
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond("**User Trial Successfully Created**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await trial_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'renew-shadowsocks'))
async def renew_shadowsocks(event):
    async def renew_shadowsocks_(event):
        sender = await event.get_sender()
        if not valid(str(sender.id)):
            await event.answer("Akses Ditolak", alert=True)
            return

        chat = event.chat_id

        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses renew akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                # Tanya username dan lama hari
                await conv.send_message("**Username to be RENEW:**")
                user_response = await conv.get_response()
                user = user_response.raw_text.strip()

                await conv.send_message("**Days:**")
                days_response = await conv.get_response()
                days = days_response.raw_text.strip()

            cmd = f'printf "%s\n%s\n" "{user}" "{days}" | bot-renew-ss'

            # Pesan loading
            loading_msg = await event.respond("⏳ Proses renew akun...")

            result = subprocess.check_output(cmd, shell=True, text=True)
            await loading_msg.delete()
            await delete_previous_menu(sender.id)

            await event.respond(
                f"{result}\n**RENEW SHADOWSOCKS**\n**» 🤖@frel01**",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )

        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"❌ User `{user}` tidak ditemukan!", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"⚠️ Error: `{str(e)}`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await renew_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'reco-shadowsocks'))
async def reco_shadowsocks(event):
    async def reco_shadowsocks_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses recover akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                user_response = await conv.get_response()
                user = user_response.raw_text
        
            # Panggil shell script dengan default 0 untuk param opsional
            cmd = f'./bot-recover-ss "{user}" "0" "0" "0"'
            
            loading_msg = await event.respond("⏳ Memeriksa detail akun...")
            
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Detail untuk user** `{user}`:\n\n{result}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"❌ **User `{user}` tidak ditemukan!**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await reco_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    async def delete_shadowsocks_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses delete akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message('**Username:**')
                user_response = await conv.get_response()
                user = user_response.raw_text
        
            cmd = f'printf "%s\n" "{user}" | del-ss'

            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses delete akun...")
            
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**User `{user}` Successfully Deleted**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**Error:** {str(e)}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await delete_shadowsocks_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'shadowsocks'))
async def shadowsocks_menu(event):
    async def shadowsocks_menu_(event):
        inline = [
            [Button.inline("🔰 TRIAL", "trial-shadowsocks"), 
             Button.inline("✨ CREATE", "create-shadowsocks")],
            [Button.inline("🔄 RENEW", "renew-shadowsocks"),
             Button.inline("📊 DETAIL", "reco-shadowsocks")],
            [Button.inline("🔍 CHECK", "cek-shadowsocks"),
             Button.inline("🗑️ DELETE", "delete-shadowsocks")],
            [Button.inline("🔒 LOCK", "lock-shadowsocks"),
             Button.inline("🔓 UNLOCK", "unlock-shadowsocks")],
            [Button.inline("👥 SHOW All USER", "show-ss"),
             Button.inline("⚙️ GANTI LIMIT IP", "limit-ss")],
            [Button.inline("🏠 ‹ Main Menu ›", "menu")]
        ]
        
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=10).json()
            msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🌐 SHADOWSOCKS MANAGER 🌐**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Service:** `SHADOWSOCKS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z.get("isp", "Unknown")}`
**» Country:** `{z.get("country", "Unknown")}`
🤖 **» @frel01**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        except:
            msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🌐 SHADOWSOCKS MANAGER 🌐**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Service:** `SHADOWSOCKS`
**» Hostname/IP:** `{DOMAIN}`
🤖 **» @frel01**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

        user_id = event.sender_id

        try:
            # Hapus pesan menu sebelumnya
            await delete_previous_menu(user_id)
            
            # Kirim pesan menu baru
            new_msg = await event.respond(msg, buttons=inline)
            
            # Simpan pesan terbaru
            last_menu_message[user_id] = new_msg
            
            # Hapus pesan callback jika memungkinkan
            try:
                await event.delete()
            except:
                pass
                
        except Exception as e:
            print(f"Error sending menu: {e}")

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a:
        await shadowsocks_menu_(event)
    else:
        await event.answer("Access Denied", alert=True)