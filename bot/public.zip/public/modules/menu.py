from public import *
import asyncio
import time
import subprocess
from datetime import timedelta
from telethon import Button, events
import logging

# Setup logging untuk debug
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot_start_time = time.time()
last_menu_message = {}

async def delete_previous_menu(user_id):
    """Hapus pesan menu sebelumnya"""
    if user_id in last_menu_message:
        try:
            await last_menu_message[user_id].delete()
            del last_menu_message[user_id]
        except:
            pass

# Cache untuk informasi sistem dengan waktu kedaluwarsa
class SystemInfoCache:
    def __init__(self, duration=30):
        self.cache = {}
        self.duration = duration
    
    def get(self, key):
        if key in self.cache:
            value, timestamp = self.cache[key]
            if time.time() - timestamp < self.duration:
                return value
        return None
    
    def set(self, key, value):
        self.cache[key] = (value, time.time())
    
    def clear(self):
        count = len(self.cache)
        self.cache = {}
        return count

system_info_cache = SystemInfoCache()

# Cache untuk validasi user
user_access_cache = {}

async def get_cached_system_info(key, command, default="Unknown", timeout=3):
    """Cache informasi sistem untuk mengurangi panggilan subprocess"""
    cached = system_info_cache.get(key)
    if cached is not None:
        return cached
    
    try:
        # Gunakan asyncio untuk proses non-blocking
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        result = stdout.decode().strip() or default
        
        system_info_cache.set(key, result)
        return result
    except (asyncio.TimeoutError, subprocess.SubprocessError) as e:
        logger.error(f"Error executing command {command}: {str(e)}")
        system_info_cache.set(key, default)
        return default

# Preload data yang sering digunakan
async def preload_common_data():
    """Preload data yang sering digunakan untuk respon lebih cepat"""
    common_commands = {
        "ssh": 'cat /etc/passwd | grep "home" | grep "false" | wc -l',
        "vms": 'cat /etc/vmess/.vmess.db | grep "###" | wc -l',
        "vls": 'cat /etc/vless/.vless.db | grep "###" | wc -l',
        "trj": 'cat /etc/trojan/.trojan.db | grep "###" | wc -l',
        "ss": 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l',
        "os": 'cat /etc/os-release | grep "PRETTY_NAME" | cut -d= -f2 | tr -d \'"\'',
        "ip": 'curl -s ifconfig.me || curl -s ipinfo.io/ip || hostname -I | awk \'{print $1}\''
    }
    
    # Preload data secara paralel
    tasks = []
    for key, cmd in common_commands.items():
        tasks.append(get_cached_system_info(key, cmd))
    
    await asyncio.gather(*tasks)
    logger.info("Preload data completed")

async def handle_access_denied(event):
    """Menangani akses ditolak dengan lebih efisien"""
    try:
        if isinstance(event, events.CallbackQuery.Event):
            await event.answer("Akses Ditolak", alert=True)
        else:
            await event.reply("❌ **Akses Ditolak**\nAnda tidak memiliki izin untuk menggunakan bot ini.")
    except Exception as e:
        logger.error(f"Error in handle_access_denied: {str(e)}")
        
# =========================
# ADMIN PANEL
# =========================

admin_action_state = {}  # simpan state per admin yang klik tombol

@bot.on(events.CallbackQuery(data=b"admin_menu"))
async def admin_menu(event):
    if not valid(str(event.sender_id)):
        await handle_access_denied(event)
        return

    teks = "👑 **ADMIN PANEL**\n\nPilih aksi:"
    buttons = [
        [Button.inline("➕ Tambah Admin", b"add_admin_menu")],
        [Button.inline("🗑️ Hapus Admin", b"del_admin_menu")],
        [Button.inline("📜 List Admin", b"list_admin_menu")],
        [Button.inline("⬅️ Kembali", b"menu")]
    ]
    await event.edit(teks, buttons=buttons)


@bot.on(events.CallbackQuery(data=b"add_admin_menu"))
async def add_admin_menu(event):
    user_id = event.sender_id
    admin_action_state[user_id] = "add"
    await event.edit(
        "✍️ Kirim **ID Telegram** yang mau dijadikan admin.",
        buttons=[[Button.inline("⬅️ Kembali", b"admin_menu")]]
    )


@bot.on(events.CallbackQuery(data=b"del_admin_menu"))
async def del_admin_menu(event):
    user_id = event.sender_id
    admin_action_state[user_id] = "delete"
    await event.edit(
        "✍️ Kirim **ID Telegram** admin yang mau dihapus.",
        buttons=[[Button.inline("⬅️ Kembali", b"admin_menu")]]
    )


@bot.on(events.CallbackQuery(data=b"list_admin_menu"))
async def list_admin_menu(event):
    x = get_db()
    c = x.cursor()
    c.execute("SELECT user_id FROM admin")
    admins = [row[0] for row in c.fetchall()]
    teks = "👑 List Admin:\n" + ("\n".join(admins) if admins else "⚠️ Belum ada admin")
    await event.edit(teks, buttons=[[Button.inline("⬅️ Kembali", b"admin_menu")]])


# =========================
# HANDLER INPUT ID (Add/Delete)
# =========================
@bot.on(events.NewMessage(pattern=r'^\d+$'))
async def handle_admin_id(event):
    user_id = event.sender_id

    if not valid(str(user_id)):
        await handle_access_denied(event)
        return

    if user_id not in admin_action_state:
        return  # user tidak sedang dalam mode add/del admin

    action = admin_action_state[user_id]
    target_id = event.text.strip()

    x = get_db()
    c = x.cursor()

    if action == "add":
        c.execute("INSERT INTO admin (user_id) VALUES (?)", (target_id,))
        x.commit()
        await event.reply(f"✅ Admin baru ditambahkan: {target_id}")

    elif action == "delete":
        c.execute("DELETE FROM admin WHERE user_id = ?", (target_id,))
        x.commit()
        await event.reply(f"🗑️ Admin dihapus: {target_id}")

    # Hapus state setelah selesai
    del admin_action_state[user_id]

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    try:
        sender = await event.get_sender()
        user_id = sender.id

        # Validasi akses user dengan caching yang benar
        if user_id in user_access_cache:
            if user_access_cache[user_id] == "false":
                await handle_access_denied(event)
                return
        else:
            # Asumsikan fungsi valid() ada di private.py
            access = valid(str(user_id)) if 'valid' in globals() else "true"
            user_access_cache[user_id] = access
            if access == "false":
                await handle_access_denied(event)
                return

        # Layout button yang dioptimalkan
        buttons = [
            [Button.inline("🛡️ SSH OVPN", "ssh")],
            [Button.inline("⚡ VMESS", "vmess"), Button.inline("🚀 VLESS", "vless")],
            [Button.inline("🔒 TROJAN", "trojan"), Button.inline("🌐 SOCKS", "shadowsocks")],
            [Button.inline("🔄 STATUS", "status"), Button.inline("👑 ADD ADMIN", "admin_menu")],
            [Button.inline("🗑️ CLEAR CACHE", "clear_cache")]
        ]

        username = f"@{sender.username}" if sender.username else "Tidak Ada Username"
        full_name = f"{sender.first_name or ''} {sender.last_name or ''}".strip()

        # Ambil data secara paralel untuk mempercepat
        ssh, vms , vls, trj, ss, namaos, ipsaya = await asyncio.gather(
            get_cached_system_info("ssh", 'cat /etc/passwd | grep "home" | grep "false" | wc -l', "0"),
            get_cached_system_info("vms", 'cat /etc/vmess/.vmess.db | grep "###" | wc -l', "0"),
            get_cached_system_info("vls", 'cat /etc/vless/.vless.db | grep "###" | wc -l', "0"),
            get_cached_system_info("trj", 'cat /etc/trojan/.trojan.db | grep "###" | wc -l', "0"),
            get_cached_system_info("ss", 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', "0"),
            get_cached_system_info("os", 'cat /etc/os-release | grep "PRETTY_NAME" | cut -d= -f2 | tr -d \'"\''),
            get_cached_system_info("ip", 'curl -s ifconfig.me || curl -s ipinfo.io/ip || hostname -I | awk \'{print $1}\'', timeout=3)
        )

        # Data opsional (jika gagal tidak menghambat)
        try:
            city_task = asyncio.create_task(get_cached_system_info("city", 'curl -s ipinfo.io/city 2>/dev/null || echo "Tidak Diketahui"', timeout=2))
            isp_task = asyncio.create_task(get_cached_system_info("isp", 'curl -s ipinfo.io/org 2>/dev/null | cut -d" " -f2- || echo "Tidak Diketahui"', timeout=2))
            city, isp_info = await asyncio.gather(city_task, isp_task)
        except:
            city = isp_info = "Tidak Diketahui"

        # Hitung nilai yang diperlukan
        uptime_seconds = int(time.time() - bot_start_time)
        uptime_str = str(timedelta(seconds=uptime_seconds))
        
        # Ping yang lebih akurat
        start_time = time.time()
        try:
            if hasattr(event, 'data'):
                await event.answer()
            ping_time = round((time.time() - start_time) * 1000, 2)
        except:
            ping_time = 0.0

        # Hitung total akun
        total_accounts = sum(int(x) for x in [ssh, vms, vls, trj, ss])

        # Template pesan yang dioptimalkan
        cache_count = len(system_info_cache.cache)
        try:
            domain_info = DOMAIN
        except:
            domain_info = "Tidak Diketahui"

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ **VPN MANAGEMENT BOT** ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 **INFORMASI PENGGUNA**
├─ **Nama:** `{full_name}`
├─ **Username:** `{username}`
├─ **User ID:** `{user_id}`

🖥️ **INFORMASI SISTEM**
├─ **OS:** `{namaos}`
├─ **ISP:** `{isp_info}`
├─ **Lokasi:** `{city}`
├─ **Domain:** `{domain_info}`
├─ **IP Address:** `{ipsaya}`
├─ **Cache Items:** `{cache_count}` item

📊 **STATISTIK AKUN**
├─ 🛡️ **SSH OVPN:** `{ssh}` akun
├─ ⚡ **VMESS:** `{vms}` akun
├─ 🚀 **VLESS:** `{vls}` akun
├─ 🔒 **TROJAN:** `{trj}` akun
├─ 🌐 **SHADOWSOCKS:** `{ss}` akun
├─ **Total:** `{total_accounts}` akun

🤖 **INFORMASI BOT**
├─ **Runtime:** `{uptime_str}`
├─ **Ping:** `{ping_time} ms`

━━━━━━━━━━━━━━━━━━━━━━━━━━
🔰 **Pilih layanan untuk dikelola:**
"""

        # Jika callback query, edit pesan sebelumnya
        if isinstance(event, events.CallbackQuery.Event):
            message = await event.edit(msg, buttons=buttons)
        else:
            # Hapus pesan menu sebelumnya jika ada
            if user_id in last_menu_message:
                try:
                    await last_menu_message[user_id].delete()
                except:
                    pass
            message = await event.reply(msg, buttons=buttons)

        # Simpan pesan terbaru
        last_menu_message[user_id] = message

    except Exception as e:
        logger.error(f"Error in menu handler: {str(e)}")
        # Fallback yang lebih ringan
        try:
            if isinstance(event, events.CallbackQuery.Event):
                await event.answer("Menu diperbarui", alert=False)
            else:
                # Kirim pesan sederhana tanpa format jika error
                await event.reply("Silakan pilih layanan:", buttons=[[Button.inline("‹ Coba Lagi ›", b'menu')]])
        except Exception as inner_e:
            logger.error(f"Error in fallback: {str(inner_e)}")

# Handler untuk clear cache
@bot.on(events.CallbackQuery(data=b'clear_cache'))
async def clear_cache_handler(event):
    """Handler untuk menghapus cache sistem"""
    try:
        # Hapus cache
        cleared_count = system_info_cache.clear()
        global user_access_cache
        user_access_cache = {}
        
        # Kirim konfirmasi
        confirm_msg = f"""
🗑️ **CLEAR CACHE BERHASIL**

✅ Berhasil menghapus `{cleared_count}` item cache.

Cache sistem informasi telah dibersihkan dan akan diperbarui otomatis pada permintaan berikutnya.
"""
        await event.edit(confirm_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])
        
    except Exception as e:
        error_msg = f"""
❌ **GAGAL CLEAR CACHE**

Error: `{str(e)}`

Silakan coba lagi atau hubungi administrator.
"""
        await event.edit(error_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])

# Handler untuk bantuan
@bot.on(events.CallbackQuery(data=b'help'))
async def help_handler(event):
    help_msg = """
❓ **PANDUAN & BANTUAN**
━━━━━━━━━━━━━━━━━━━━━━

**Perintah yang Tersedia:**
• `/menu` - Menampilkan menu utama
• `/start` - Memulai bot

**Layanan yang Didukung:**
• 🛡️ SSH OVPN - Protokol SSH & OpenVPN
• ⚡ VMESS - Protokol VMess (WebSocket)
• 🚀 VLESS - Protokol VLess (lebih ringan & cepat)
• 🔒 TROJAN - Protokol Trojan (lebih aman)
• 🌐 SHADOWSOCKS - Protokol Shadowsocks

**Fitur Utama:**
• Membuat akun baru
• Perpanjang akun yang sudah ada
• Hapus akun
• Cek status login pengguna
• Lihat detail akun
• Ubah batas jumlah IP
• Monitoring server
• Clear Cache System

━━━━━━━━━━━━━━━━━━━━━━━
**Dukungan:** @frel01
"""
    try:
        await event.edit(help_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])
    except:
        await event.answer("Error showing help", alert=True)

# Handler untuk status
def progress_bar(percentage, length=10):
    """Buat progress bar sederhana menggunakan ▓░"""
    try:
        percentage = max(0, min(100, int(percentage)))
    except:
        percentage = 0
    filled = int(length * percentage / 100)
    empty = length - filled
    return "▓" * filled + "░" * empty

@bot.on(events.CallbackQuery(data=b'status'))
async def status_handler(event):
    try:
        # Definisikan layanan untuk diperiksa
        services = {
            "🔐 SSH": "systemctl is-active ssh >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "🌐 OpenVPN": "systemctl is-active openvpn >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "⚡ Xray": "systemctl is-active xray >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "📦 Nginx": "systemctl is-active nginx >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "📧 Dropbear": "systemctl is-active dropbear >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "📡 Squid": "systemctl is-active squid >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "🛡️ Fail2Ban": "systemctl is-active fail2ban >/dev/null 2>&1 && echo '✅' || echo '❌'",
            "🕸️ Cron": "systemctl is-active cron >/dev/null 2>&1 && echo '✅' || echo '❌'",
        }

        # Periksa status layanan secara paralel
        status_tasks = []
        for service, cmd in services.items():
            status_tasks.append(get_cached_system_info(f"status_{service}", cmd))
        
        status_results = await asyncio.gather(*status_tasks)
        status_lines = [f"{service} : {status}" for service, status in zip(services.keys(), status_results)]

        # Dapatkan uptime server
        uptime = await get_cached_system_info("uptime", "uptime -p", "Tidak Diketahui")
        
        # Status bot
        bot_status = "✅ Online" if bot.is_connected() else "❌ Offline"

        # Dapatkan penggunaan resource secara paralel
        cpu_task = asyncio.create_task(get_cached_system_info("cpu", 
            "top -bn1 | grep 'Cpu(s)' | awk '{print $2+$4}'", "0"))
        
        # Untuk RAM dan Disk, gunakan perintah yang lebih efisien
        ram_info_task = asyncio.create_task(get_cached_system_info("ram", 
            "free | awk '/Mem:/ {printf \"%.1f\\n\", $3/$2 * 100}'", "0"))
        
        disk_info_task = asyncio.create_task(get_cached_system_info("disk", 
            "df -h / | awk 'NR==2 {print $5}' | sed 's/%//'", "0"))
        
        cpu, ram_percent, disk_percent = await asyncio.gather(cpu_task, ram_info_task, disk_info_task)
        
        # Format teks untuk ditampilkan
        try:
            cpu = f"{float(cpu):.1f}%"
            ram_text = f"{float(ram_percent):.1f}%"
            disk_text = f"{disk_percent}%"
        except:
            cpu = ram_text = disk_text = "0%"

        # Waktu saat ini
        from datetime import datetime
        now = datetime.now().strftime("%d-%m-%Y %H:%M:%S")

        status_msg = f"""
📊 **STATUS SERVER & BOT**
━━━━━━━━━━━━━━━━━━━━━━━
🤖 Bot : {bot_status}
━━━━━━━━━━━━━━━━━━━━━━━
{"\n".join(status_lines)}
━━━━━━━━━━━━━━━━━━━━━━━
💻 **Monitoring Resource**
• CPU Usage  : `{cpu}`  
  {progress_bar(float(cpu.replace('%', '')))}
• RAM Usage  : `{ram_text}`  
  {progress_bar(float(ram_text.replace('%', '')))}
• Disk Usage : `{disk_text}`  
  {progress_bar(float(disk_text.replace('%', '')))}
━━━━━━━━━━━━━━━━━━━━━━━
⌛ Update Terakhir: `{now}`
"""

        await event.edit(status_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])

    except Exception as e:
        await event.answer(f"❌ Error: {str(e)}", alert=True)

# Jalankan preload saat bot mulai
@bot.on(events.NewMessage(pattern='/preload'))
async def preload_command(event):
    """Command manual untuk preload data"""
    await preload_common_data()
    await event.reply("✅ Preload data completed!")

# Fungsi utama untuk menjalankan bot
async def main():
    """Jalankan bot dan preload data"""
    try:
        # Jalankan preload data
        await preload_common_data()
        
        # Mulai bot
        await bot.start()
        logger.info("Bot started successfully")
        
        # Jalankan bot sampai dihentikan
        await bot.run_until_disconnected()
        
    except Exception as e:
        logger.error(f"Error starting bot: {str(e)}")

# Jalankan aplikasi
if __name__ == '__main__':
    # Pastikan file private.py berisi semua yang diperlukan
    try:
        # Coba jalankan preload data dan mulai bot
        import asyncio
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")