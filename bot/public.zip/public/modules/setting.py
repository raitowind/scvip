from public import *
import asyncio
import subprocess
import requests
from telethon import Button, events
import logging
import json
from typing import Optional, Dict, List, Tuple

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store last menu state
menu_stack: Dict[int, str] = {}

class BotHandler:
    """Main bot handler class"""
    
    def __init__(self):
        self.bot = bot
        self.setup_handlers()
    
    def setup_handlers(self):
        """Setup all event handlers"""
        # Menu navigation
        self.bot.on(events.CallbackQuery(pattern=r'^menu$'))(self.back_to_main_menu)
        
        # IP Management
        self.bot.on(events.CallbackQuery(pattern=r'^ipmenu$'))(self.cb_ipmenu)
        self.bot.on(events.CallbackQuery(pattern=r'^regip$'))(self.cb_regip)
        self.bot.on(events.CallbackQuery(pattern=r'^renip$'))(self.cb_renip)
        self.bot.on(events.CallbackQuery(pattern=r'^delip$'))(self.cb_delip)
        self.bot.on(events.CallbackQuery(pattern=r'^listip$'))(self.cb_listip)
        
        # Server actions
        self.bot.on(events.CallbackQuery(pattern=r'^reboot$'))(self.cb_reboot)
        self.bot.on(events.CallbackQuery(pattern=r'^confirm_reboot$'))(self.cb_confirm_reboot)
        self.bot.on(events.CallbackQuery(pattern=r'^resx$'))(self.cb_resx)
        self.bot.on(events.CallbackQuery(pattern=r'^confirm_resx$'))(self.cb_confirm_resx)
        
        # Other features
        self.bot.on(events.CallbackQuery(pattern=r'^speedtest$'))(self.cb_speedtest)
        self.bot.on(events.CallbackQuery(pattern=r'^backup$'))(self.cb_backup)
        self.bot.on(events.CallbackQuery(pattern=r'^restore$'))(self.cb_restore)
        self.bot.on(events.CallbackQuery(pattern=r'^point$'))(self.cb_point)
        self.bot.on(events.CallbackQuery(pattern=r'^backer$'))(self.cb_backer)
        self.bot.on(events.CallbackQuery(pattern=r'^setting$'))(self.cb_settings)
    
    async def animate_loading(self, message, text: str) -> None:
        """Animate loading message with dots"""
        dots = ["⏳" + text + ".", "⏳" + text + "..", "⏳" + text + "..."]
        for dot in dots:
            try:
                await message.edit(dot)
            except Exception as e:
                logger.error(f"Error editing message: {e}")
                return
            await asyncio.sleep(0.5)
    
    async def handle_conversation(self, event, question: str, timeout: int = 60) -> Optional[str]:
        """Handle conversation with user"""
        async with self.bot.conversation(event.chat_id) as conv:
            await conv.send_message(question)
            try:
                response = await conv.wait_event(
                    events.NewMessage(from_users=event.sender_id), 
                    timeout=timeout
                )
                return response.raw_text
            except asyncio.TimeoutError:
                await event.respond("⏰ Waktu input habis.", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
                return None
    
    async def go_back_to_menu(self, event) -> None:
        """Return to main menu"""
        user_id = event.sender_id
        if user_id in menu_stack:
            del menu_stack[user_id]
        
        # Import here to avoid circular imports
        from main_menu import show_main_menu
        await show_main_menu(event)
    
    async def back_to_main_menu(self, event):
        """Callback for returning to main menu"""
        await self.go_back_to_menu(event)
    
    async def get_server_info(self) -> Dict[str, str]:
        """Get server information from IP API"""
        try:
            response = requests.get(
                "http://ip-api.com/json/?fields=country,region,city,timezone,isp", 
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Error getting server info: {e}")
            return {}
    
    async def execute_command(self, cmd: str, timeout: int = 300) -> Tuple[bool, str]:
        """Execute shell command and return result"""
        try:
            result = subprocess.run(
                cmd, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=timeout
            )
            return result.returncode == 0, result.stdout.strip() or result.stderr.strip()
        except subprocess.TimeoutExpired:
            return False, "Command timed out"
        except Exception as e:
            return False, str(e)
    
    # ===================== IP Management Menu =====================
    async def cb_ipmenu(self, event):
        """IP Management Menu"""
        menu_stack[event.sender_id] = "ipmenu"
        
        # Get server info
        server_info = await self.get_server_info()
        
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🌐 IP MANAGEMENT MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{server_info.get('isp', 'Unknown')}`
**» Country:** `{server_info.get('country', 'Unknown')}`
🤖 **» @frel01**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        
        inline = [
            [Button.inline("🌐 REGISTER IP", "regip"), Button.inline("🔄 RENEW IP", "renip")],
            [Button.inline("🗑️ DELETE IP", "delip"), Button.inline("📋 LIST IP", "listip")],
            [Button.inline("‹ Back to Settings ›", "setting"), Button.inline("‹ Main Menu ›", "menu")]
        ]
        
        await event.edit(msg, buttons=inline)
    
    # ===================== IP Management =====================
    async def ip_management_handler(self, event, action: str) -> None:
        """Handle IP management operations"""
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        menu_stack[event.sender_id] = action
        
        try:
            # Get required inputs based on action
            inputs = []
            if action == "regip":
                inputs = [
                    ('**VERIFIKASI ADMIN:**', 'user'),
                    ('**IP VPS:**', 'dom'),
                    ('**NAMA CLIENT:**', 'sub'),
                    ('**Expired:**', 'ipvps')
                ]
            elif action == "renip":
                inputs = [
                    ('**VERIFIKASI ADMIN:**', 'user'),
                    ('**IP VPS:**', 'dom'),
                    ('**Expired:**', 'ipvps')
                ]
            elif action == "delip":
                inputs = [
                    ('**VERIFIKASI ADMIN:**', 'user'),
                    ('**IP VPS:**', 'dom')
                ]
            elif action == "listip":
                inputs = [('**VERIFIKASI ADMIN:**', 'user')]
            else:
                return
            
            # Collect inputs
            values = {}
            for question, key in inputs:
                response = await self.handle_conversation(event, question)
                if not response:
                    return
                values[key] = response
            
            # Build command based on action
            if action == "regip":
                cmd = f'printf "%s\\n" "{values["user"]}" "{values["dom"]}" "{values["sub"]}" "{values["ipvps"]}" | bot-manage-ip addip'
                loading_text = "Proses register IP"
            elif action == "renip":
                cmd = f'printf "%s\\n" "{values["user"]}" "{values["dom"]}" "{values["ipvps"]}" | bot-manage-ip renewip'
                loading_text = "Proses renew IP"
            elif action == "delip":
                cmd = f'printf "%s\\n" "{values["user"]}" "{values["dom"]}" | bot-manage-ip delip'
                loading_text = "Proses delete IP"
            elif action == "listip":
                cmd = f'printf "%s\\n" "{values["user"]}" | bot-manage-ip listip'
                loading_text = "Memuat daftar IP"
            
            # Show loading animation
            loading_msg = await event.respond(f"⏳ {loading_text}...")
            loading_task = asyncio.create_task(self.animate_loading(loading_msg, loading_text))
            
            # Execute command
            success, result = await self.execute_command(cmd)
            
            # Cancel loading and show result
            loading_task.cancel()
            await loading_msg.delete()
            
            if success:
                if action == "listip":
                    await event.respond(
                        f"**📋 LIST IP TERDAFTAR**\n\n{result}\n**🤖 @frel01**",
                        buttons=[
                            [Button.inline("‹ Back to IP Menu ›", "ipmenu")],
                            [Button.inline("‹ Main Menu ›", "menu")]
                        ]
                    )
                else:
                    await event.respond(
                        f"**✅ Successfully {action.upper()}**",
                        buttons=[
                            [Button.inline("‹ Back to IP Menu ›", "ipmenu")],
                            [Button.inline("‹ Main Menu ›", "menu")]
                        ]
                    )
            else:
                await event.respond(
                    f"**❌ Gagal {action.upper()}**\nError: {result}",
                    buttons=[
                        [Button.inline("‹ Back to IP Menu ›", "ipmenu")],
                        [Button.inline("‹ Main Menu ›", "menu")]
                    ]
                )
                
        except Exception as e:
            logger.error(f"Error in IP management: {e}")
            await event.respond(
                f"**❌ Error: {str(e)}**",
                buttons=[
                    [Button.inline("‹ Back to IP Menu ›", "ipmenu")],
                    [Button.inline("‹ Main Menu ›", "menu")]
                ]
            )
    
    async def cb_regip(self, event):
        await self.ip_management_handler(event, "regip")
    
    async def cb_renip(self, event):
        await self.ip_management_handler(event, "renip")
    
    async def cb_delip(self, event):
        await self.ip_management_handler(event, "delip")
    
    async def cb_listip(self, event):
        await self.ip_management_handler(event, "listip")
    
    # ===================== Server Actions =====================
    async def confirm_action(self, event, action: str, confirm_text: str, confirm_pattern: str) -> bool:
        """Confirm action with user"""
        confirm = await event.respond(
            confirm_text,
            buttons=[
                [Button.inline("✅ Ya", confirm_pattern)],
                [Button.inline("❌ Tidak", "menu")]
            ]
        )
        
        try:
            response = await self.bot.wait_for(
                events.CallbackQuery(from_users=event.sender_id), 
                timeout=30
            )
            if response.data == b'menu':
                await confirm.delete()
                return False
            return True
        except asyncio.TimeoutError:
            await confirm.delete()
            await event.respond("⏰ Waktu konfirmasi habis.", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return False
    
    async def reboot_server(self, event):
        """Reboot server"""
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        menu_stack[event.sender_id] = "reboot"
        
        confirmed = await self.confirm_action(
            event, 
            "reboot", 
            "**⚠️ KONFIRMASI REBOOT SERVER**\nApakah Anda yakin?",
            "confirm_reboot"
        )
        
        if not confirmed:
            return
        
        loading_msg = await event.respond("⏳ Rebooting server...")
        loading_task = asyncio.create_task(self.animate_loading(loading_msg, "Rebooting server"))
        
        success, result = await self.execute_command("reboot", timeout=30)
        
        loading_task.cancel()
        await loading_msg.delete()
        
        if success:
            await event.respond(
                "**✅ REBOOT SERVER DIMULAI**\n**» 🤖 @frel01**",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
        else:
            await event.respond(
                f"**❌ Gagal melakukan reboot**\nError: {result}",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
    
    async def cb_reboot(self, event):
        await self.reboot_server(event)
    
    async def cb_confirm_reboot(self, event):
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        loading_msg = await event.respond("⏳ Rebooting server...")
        loading_task = asyncio.create_task(self.animate_loading(loading_msg, "Rebooting server"))
        
        success, result = await self.execute_command("reboot", timeout=30)
        
        loading_task.cancel()
        await loading_msg.delete()
        
        if success:
            await event.respond(
                "**✅ REBOOT SERVER DIMULAI**\n**» 🤖 @frel01**",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
        else:
            await event.respond(
                f"**❌ Gagal melakukan reboot**\nError: {result}",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
    
    async def restart_services(self, event):
        """Restart services"""
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        menu_stack[event.sender_id] = "resx"
        
        confirmed = await self.confirm_action(
            event, 
            "restart", 
            "**⚠️ KONFIRMASI RESTART SERVICES**\nApakah Anda yakin?",
            "confirm_resx"
        )
        
        if not confirmed:
            return
        
        cmd = 'systemctl restart xray nginx haproxy server udp-custom noobzvpns client'
        loading_msg = await event.respond("⏳ Restarting services...")
        loading_task = asyncio.create_task(self.animate_loading(loading_msg, "Restarting services"))
        
        success, result = await self.execute_command(cmd, timeout=60)
        
        loading_task.cancel()
        await loading_msg.delete()
        
        if success:
            await event.respond(
                "**✅ Restarting Service Done**\n**» 🤖 @frel01**",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
        else:
            await event.respond(
                f"**❌ Gagal restart services**\nError: {result}",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
    
    async def cb_resx(self, event):
        await self.restart_services(event)
    
    async def cb_confirm_resx(self, event):
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        cmd = 'systemctl restart xray nginx haproxy server udp-custom'
        loading_msg = await event.respond("⏳ Restarting services...")
        loading_task = asyncio.create_task(self.animate_loading(loading_msg, "Restarting services"))
        
        success, result = await self.execute_command(cmd, timeout=60)
        
        loading_task.cancel()
        await loading_msg.delete()
        
        if success:
            await event.respond(
                "**✅ Restarting Service Done**\n**» 🤖 @frel01**",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
        else:
            await event.respond(
                f"**❌ Gagal restart services**\nError: {result}",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
    
    # ===================== Speedtest =====================
    async def cb_speedtest(self, event):
        """Run speedtest"""
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        menu_stack[event.sender_id] = "speedtest"
        loading_msg = await event.respond("⏳ Running speedtest...")
        loading_task = asyncio.create_task(self.animate_loading(loading_msg, "Running speedtest"))
        
        success, result = await self.execute_command('speedtest-cli --share', timeout=120)
        
        loading_task.cancel()
        await loading_msg.delete()
        
        if success:
            # Find URL in speedtest result
            url_line = None
            for line in result.split('\n'):
                if 'http' in line:
                    url_line = line
                    break
            
            if url_line:
                await event.respond(
                    f"**📊 SPEEDTEST RESULT**\n{url_line}\n**» 🤖 @frel01**",
                    buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
                )
            else:
                await event.respond(
                    "**📊 SPEEDTEST RESULT**\nHasil tidak ditemukan\n**» 🤖 @frel01**",
                    buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
                )
        else:
            await event.respond(
                f"**❌ Gagal melakukan speedtest**\nError: {result}",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
    
    # ===================== Backup & Restore =====================
    async def backup_restore_handler(self, event, action: str) -> None:
        """Handle backup and restore operations"""
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        menu_stack[event.sender_id] = action
        
        prompt = "**📝 Prosess backup type y/n:**" if action == "backup" else "**🔗 Input Link Backup:**"
        user_input = await self.handle_conversation(event, prompt)
        
        if not user_input:
            return
        
        cmd = f'printf "%s\\n" "{user_input}" | bot-{action}'
        loading_msg = await event.respond(f"⏳ Proses {action}...")
        loading_task = asyncio.create_task(self.animate_loading(loading_msg, f"Proses {action}"))
        
        success, result = await self.execute_command(cmd, timeout=300)
        
        loading_task.cancel()
        await loading_msg.delete()
        
        if success:
            await event.respond(
                f"**✅ {action.upper()} COMPLETE**\n**🤖 @frel01**",
                buttons=[
                    [Button.inline("‹ Back to Backup Menu ›", "backer")],
                    [Button.inline("‹ Main Menu ›", "menu")]
                ]
            )
        else:
            await event.respond(
                f"**❌ {action.capitalize()} failed**\nError: {result}",
                buttons=[
                    [Button.inline("‹ Back to Backup Menu ›", "backer")],
                    [Button.inline("‹ Main Menu ›", "menu")]
                ]
            )
    
    async def cb_backup(self, event):
        await self.backup_restore_handler(event, "backup")
    
    async def cb_restore(self, event):
        await self.backup_restore_handler(event, "restore")
    
    # ===================== Pointing Domain =====================
    async def cb_point(self, event):
        """Point domain to IP"""
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        
        menu_stack[event.sender_id] = "point"
        
        try:
            inputs = [
                ('**VERIFIKASI ADMIN:**', 'user'),
                ('**DOMAIN:**', 'pw'),
                ('**SUB DOMAIN:**', 'pw1'),
                ('**IP-VPS:**', 'exp')
            ]
            
            values = {}
            for question, key in inputs:
                response = await self.handle_conversation(event, question)
                if not response:
                    return
                values[key] = response
            
            cmd = f'printf "%s\\n" "{values["user"]}" "{values["pw"]}" "{values["pw1"]}" "{values["exp"]}" | bot-cf'
            loading_msg = await event.respond("⏳ Proses pointing domain...")
            loading_task = asyncio.create_task(self.animate_loading(loading_msg, "Proses pointing domain"))
            
            success, result = await self.execute_command(cmd, timeout=60)
            
            loading_task.cancel()
            await loading_msg.delete()
            
            if success:
                await event.respond(
                    f"**✅ VPS `{values['exp']}` Successfully Pointing**",
                    buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
                )
            else:
                await event.respond(
                    f"**❌ Gagal melakukan pointing**\nError: {result}",
                    buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
                )
                
        except Exception as e:
            logger.error(f"Error in pointing domain: {e}")
            await event.respond(
                f"**❌ Error: {str(e)}**",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
    
    # ===================== Backer Menu =====================
    async def cb_backer(self, event):
        """Backup & Restore Menu"""
        menu_stack[event.sender_id] = "backer"
        
        # Get server info
        server_info = await self.get_server_info()
        
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**💾 BACKUP & RESTORE MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{server_info.get('isp', 'Unknown')}`
**» Country:** `{server_info.get('country', 'Unknown')}`
🤖 **» @frel01**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        
        inline = [
            [Button.inline("💾 BACKUP", "backup"), Button.inline("🔄 RESTORE", "restore")],
            [Button.inline("‹ Back to Settings ›", "setting"), Button.inline("‹ Main Menu ›", "menu")]
        ]
        
        await event.edit(msg, buttons=inline)
    
    # ===================== Settings Menu =====================
    async def cb_settings(self, event):
        """Settings Menu"""
        menu_stack[event.sender_id] = "setting"
        
        # Get server info
        server_info = await self.get_server_info()
        
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**⚙️ SETTINGS MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{server_info.get('isp', 'Unknown')}`
**» Country:** `{server_info.get('country', 'Unknown')}`
🤖 **» @frel01**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        
        inline = [
            [Button.inline("📊 SPEEDTEST", "speedtest"), Button.inline("💾 M-BACKUP", "backer")],
            [Button.inline("🔄 REBOOT", "reboot"), Button.inline("⚡ RESTART", "resx")],
            [Button.inline("🌐 REGIS IP", "ipmenu"), Button.inline("🔗 POINTING", "point")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        
        await event.edit(msg, buttons=inline)

# Initialize bot handler
bot_handler = BotHandler()

# Run the bot
if __name__ == "__main__":
    print("Bot started...")
    bot.run_until_disconnected()