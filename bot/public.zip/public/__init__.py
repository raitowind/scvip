from telethon import TelegramClient, events, Button
from menu import show_menu  
from public import bot, valid  
import datetime as DT
import sqlite3, math, os, logging, json


logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# load var.txt
exec(open("/usr/bin/public/var.txt", "r").read())  # pastikan ada BOT_TOKEN & ADMIN

# inisialisasi bot
bot = TelegramClient("ddsdswl", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# fungsi koneksi db
def get_db():
    x = sqlite3.connect("/usr/bin/public/database.db")
    x.row_factory = sqlite3.Row
    return x

# inisialisasi tabel admin dan update ID baru
def init_admin():
    db = get_db()
    c = db.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id INTEGER PRIMARY KEY)")
    # ambil ID admin dari var.txt
    admin_ids = [int(a.strip()) for a in ADMIN.split()]
    for admin_id in admin_ids:
        c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (admin_id,))
    db.commit()
    db.close()

# cek apakah user_id admin
def valid(user_id):
    db = get_db()
    c = db.cursor()
    c.execute("SELECT 1 FROM admin WHERE user_id = ?", (user_id,))
    result = c.fetchone() is not None
    db.close()
    return result

# utilitas konversi size
def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

# inisialisasi admin
init_admin()

# handler tombol callback
@bot.on(events.CallbackQuery)
async def handler(event):
    user_id = event.sender_id
    data = event.data.decode("utf-8")

    # cek admin
    if not valid(user_id):
        await event.answer("❌ Kamu bukan admin!", alert=True)
        return

    # tombol verifikasi admin
    if data == "test-button":
        await event.answer("✅ Verifikasi selesai, Anda adalah admin!", alert=True)
        # langsung ke menu.py
        await show_menu(event.chat_id)

    # tombol batal
    elif data == "cancel":
        await event.edit("❌ Aksi dibatalkan.")

# tombol awal verifikasi
async def send_verification_menu(chat_id):
    await bot.send_message(chat_id, "Pilih tombol:", buttons=[
        [Button.inline("Verifikasi Admin", b"test-button")],
        [Button.inline("Batal", b"cancel")]
    ])

# command /menu
@bot.on(events.NewMessage(pattern="/menu"))
async def menu_cmd(event):
    if valid(event.sender_id):
        await send_verification_menu(event.chat_id)
    else:
        await event.reply("❌ Kamu bukan admin!")

print("Bot siap...")
bot.run_until_disconnected()
