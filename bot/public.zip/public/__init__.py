from telethon import TelegramClient, events, Button
import datetime as DT
import sqlite3, math, os, logging, json

logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# load var.txt
exec(open("/usr/bin/public/var.txt", "r").read())  # pastikan ada BOT_TOKEN & ADMIN

# inisialisasi bot
bot = TelegramClient("ddsdswl", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# fungsi koneksi db
def get_db():
    x = sqlite3.connect("/usr/bin/public/database.db")
    x.row_factory = sqlite3.Row
    return x

# inisialisasi tabel admin dan update ID baru
def init_admin():
    db = get_db()
    c = db.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id INTEGER PRIMARY KEY)")
    # ambil ID admin dari var.txt
    admin_ids = [int(a.strip()) for a in ADMIN.split()]
    for admin_id in admin_ids:
        c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (admin_id,))
    db.commit()
    db.close()

# cek apakah user_id admin
def valid(user_id):
    db = get_db()
    c = db.cursor()
    c.execute("SELECT 1 FROM admin WHERE user_id = ?", (user_id,))
    result = c.fetchone() is not None
    db.close()
    return result

# utilitas konversi size
def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

# inisialisasi admin
init_admin()

# contoh handler tombol dengan validasi admin
@bot.on(events.CallbackQuery)
async def handler(event):
    user_id = event.sender_id
    # cek admin
    if not valid(user_id):
        await event.answer("❌ Kamu bukan admin!", alert=True)
        return

    data = event.data.decode("utf-8")
    if data == "test-button":
        await event.edit("✅ Tombol berhasil ditekan oleh admin!")
    # bisa tambah tombol lain di sini
    # elif data == "button-lain":
    #     ...

# contoh membuat menu tombol
async def send_menu(chat):
    await bot.send_message(chat, "Pilih tombol:", buttons=[
        [Button.inline("Test Button", b"test-button")],
        [Button.inline("Batal", b"cancel")]
    ])

# contoh command untuk admin
@bot.on(events.NewMessage(pattern="/menu"))
async def menu_cmd(event):
    if valid(event.sender_id):
        await send_menu(event.chat_id)
    else:
        await event.reply("❌ Kamu bukan admin!")

print("Bot siap...")
bot.run_until_disconnected()
